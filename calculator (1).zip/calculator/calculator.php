<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>calculator</title>
   
</head>
<style>
*{
    margin:0;
    padding:0;
    box-sizing: border-box;
    font-family:Arial, Helvetica, sans-serif ;
    letter-spacing: 1px;
}
body{ 
   width: 100%;
    height:800px;
    display:flex;
    justify-content: center;
    align-items:center;
    background:linear-gradient(45deg,rgb(145, 140, 134),rgb(158, 130, 148));
    background-repeat: no-repeat;
    background-size: 100% 100%;
    float: left;
}
.calculator{
    border: 5px solid rgb(rgb(118, 120, 115), green, blue);
    padding:15px;
    border-radius:10px;
    border-color:9px black;
    background:transparent;
    box-shadow: 0px 0px 15px rgb(12, 12, 12);
}
input{
    width:300px;
    border:none;
    padding:10px;
    margin:9px;
    color:white;
    background:transparent;
   box-shadow:0px 3px 7px black;
    font-size:40px;
    cursor:pointer;
}
input::placeholder{
    color:white;
 
}

button{
    border:none;
    width:60px;
    height:60px;
    margin:10px;
    border-radius:10%;
   background: transparent;
    color:white;
    font-size: 20px;
   box-shadow: 3px 4px 6px white;
    cursor: pointer;
}
.op{
    color:rgb(54, 10, 230);
    font-weight:600px;
    font-size:35px;
    background-color:rgb(165, 32, 32);
    color:black;
    
}
.opp{
    background-color:rgb(165, 32, 32);
    color:rgb(47, 47, 49);
}
.o{
  background-color:rgb(202, 205, 188);
  color:black;
}

</style>
<body>
  
   <div class="calculator" style="background-color:rgb(73, 59, 59) ;">
  <div>
    <input type ="text"  id="display"  placeholder="0" style="background: rgb(97, 142, 97);";>
</div>
<div>
<button class="op" onclick="clearDisplay()">C </button>
<button class="op" onclick="appendToDisplay('%')">%</button>
<button class="op" onclick="appendToDisplay('/')">/</button>
</div>
<div >
    <button class="o" onclick="appendToDisplay('7')">7</button>
    <button class="o" onclick="appendToDisplay('8')">8</button>
    <button class="o" onclick="appendToDisplay('9')">9</button>
    <button class="op"  onclick="appendToDisplay('')"></button>
</div>
<div>
    <button class="o" onclick="appendToDisplay('4')">4</button>
    <button class="o" onclick="appendToDisplay('5')">5</button>
    <button  class="o" onclick="appendToDisplay('6')">6</button>
    <button class="op"  onclick="appendToDisplay('-')">-</button>
    </div>
<div >
        <button class="o" onclick="appendToDisplay('1')">1</button>
        <button class="o" onclick="appendToDisplay('2')">2</button>
        <button  class="o" onclick="appendToDisplay('3')">3</button>
        <button   onclick="appendToDisplay('+')" class="op">+</button>
</div>
<div >
    <button  class="o" onclick="appendToDisplay('00')">00</button>
    <button  class="o" onclick="appendToDisplay('0')">0</button>
  <button class="opp"  onclick="calculate()">=</button>
   <button class="op"  onclick="appendToDisplay('.')">.</button>
</div>
</div>
<script>
    
  function appendToDisplay(value) {
    document.getElementById('display').value += value;
  }

  function clearDisplay() {
    document.getElementById('display').value = '';
  }

  function calculate() {
    try  {
      document.getElementById('display').value = eval(document.getElementById('display').value);
    } 
    catch(err)
     {
      document.getElementById('display').value = 'Error';
    }
  }
</script>


</body>


</html>